package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class Result(
    val name: String,
    val url: String
)