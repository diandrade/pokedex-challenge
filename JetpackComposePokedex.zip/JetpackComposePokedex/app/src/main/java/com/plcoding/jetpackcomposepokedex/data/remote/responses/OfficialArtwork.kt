package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class OfficialArtwork(
    val front_default: String
)