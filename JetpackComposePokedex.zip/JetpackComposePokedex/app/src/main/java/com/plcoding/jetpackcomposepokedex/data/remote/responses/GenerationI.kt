package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class GenerationI(
    val red_blue: RedBlue,
    val yellow: Yellow
)