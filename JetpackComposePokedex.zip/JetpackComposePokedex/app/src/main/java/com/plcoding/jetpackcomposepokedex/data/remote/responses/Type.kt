package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class Type(
    val slot: Int,
    val type: TypeX
)