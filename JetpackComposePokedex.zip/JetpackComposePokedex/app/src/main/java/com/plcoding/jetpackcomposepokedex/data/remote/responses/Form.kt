package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class Form(
    val name: String,
    val url: String
)