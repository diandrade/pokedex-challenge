package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class Other(
    val dream_world: DreamWorld,
    val home: Home,
    val official_artwork: OfficialArtwork
)