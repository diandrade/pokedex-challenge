package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class Version(
    val name: String,
    val url: String
)