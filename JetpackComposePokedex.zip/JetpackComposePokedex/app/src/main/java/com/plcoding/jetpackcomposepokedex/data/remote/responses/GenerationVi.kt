package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class GenerationVi(
    val omegaruby_alphasapphire: OmegarubyAlphasapphire,
    val x_y: XY
)