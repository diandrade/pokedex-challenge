package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class GenerationVii(
    val icons: Icons,
    val ultra_sun_ultra_moon: UltraSunUltraMoon
)