package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class Emerald(
    val front_default: String,
    val front_shiny: String
)