package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class GenerationIii(
    val emerald: Emerald,
    val firered_leafgreen: FireredLeafgreen,
    val ruby_sapphire: RubySapphire
)