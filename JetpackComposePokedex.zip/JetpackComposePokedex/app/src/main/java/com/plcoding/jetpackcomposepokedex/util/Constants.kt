package com.plcoding.jetpackcomposepokedex.util

object Constants {

    const val BASE_URL = "https://pokeapi.co/api/v2/"
}