package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class MoveX(
    val name: String,
    val url: String
)