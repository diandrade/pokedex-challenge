package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class GenerationV(
    val black_white: BlackWhite
)