package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class Species(
    val name: String,
    val url: String
)