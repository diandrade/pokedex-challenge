package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class OmegarubyAlphasapphire(
    val front_default: String,
    val front_female: Any,
    val front_shiny: String,
    val front_shiny_female: Any
)