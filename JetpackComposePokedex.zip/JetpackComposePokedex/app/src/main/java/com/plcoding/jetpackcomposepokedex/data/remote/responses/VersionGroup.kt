package com.plcoding.jetpackcomposepokedex.data.remote.responses

data class VersionGroup(
    val name: String,
    val url: String
)